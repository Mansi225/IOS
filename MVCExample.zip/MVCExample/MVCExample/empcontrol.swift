

import UIKit

protocol empdelegate
{
    func getdata(str:String)
}

class empcontrol: NSObject
{
    var delegate:empdelegate?
    func insert(obj:employee,url:String)
    {
        let finalurl = URL(string: url)
        let dic = ["id":obj.id,"name":obj.name,"address":obj.address,"mon":obj.mon,"img":obj.img] as [String : Any]
        do
        {
            let jsondata = try JSONSerialization.data(withJSONObject: dic, options: [])
            var request = URLRequest(url: finalurl!)
            request.addValue(String(describing: jsondata), forHTTPHeaderField: "Content-Length")
            request.httpBody = jsondata
            request.httpMethod = "POST"
            let session = URLSession.shared
            let datatask = session.dataTask(with: request, completionHandler: { (data1, resp, err) in
                DispatchQueue.main.async {
                    let strresp = String(data: data1!, encoding: String.Encoding.utf8)
                self.delegate?.getdata(str: strresp!)
                }
            })
            datatask.resume()
        }
        catch
        {}
    }
}
