//
//  employee.swift
//  MVCExample
//
//  Created by TOPS on 10/20/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class employee: NSObject
{
    var id : Int?
    var name : String?
    var address : String?
    var mon : String?
    var img : String?
    init(id:Int,name:String,address:String,mon:String,img:String)
    {
        self.id = id
        self.name = name
        self.address = address
        self.mon = mon
        self.img = img
    }
}
