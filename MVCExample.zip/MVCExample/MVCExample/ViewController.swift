

import UIKit

class ViewController: UIViewController,empdelegate
{
    
    @IBOutlet weak var txtId: UITextField!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAdd: UITextField!
    @IBOutlet weak var txtMob: UITextField!
    @IBOutlet weak var img: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
    }
    
    func getdata(str: String)
    {
        print(str)
    }
    
    
    @IBAction func btn(_ sender: Any)
    {
        let data1 = UIImageJPEGRepresentation(img.image!, 1.2)
        let base = data1?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
        let obj = employee(id: Int(txtId.text!)!, name: txtName.text!, address: txtAdd.text!, mon: txtMob.text!, img: base!)
        let main = empcontrol()
        main.delegate = self
        main.insert(obj: obj, url: "http://localhost/KrimaDB/postInsert.php")
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()

    }


}

