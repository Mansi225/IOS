//
//  ViewController.swift
//  SQLitExample
//
//  Created by TOPS on 10/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var txtID: UITextField!
    
    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var txtAdd: UITextField!
    
    var arr : [Any] = []
    let db = DMLOperations()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let db = DMLOperations()
        var arr = db.getdata(strquery: "select * from emp")
        
        print(arr)
        
    }
    
    

    @IBAction func btnInsert(_ sender: Any)
    {
        let query = "insert into emp(eid,ename,eadd)values('\(txtID.text!)','\(txtName.text!)','\(txtAdd.text!)')"
        //print(query)
        let db = DMLOperations()
        let st = db.dml(query: query)
        if st == true
        {
            print("Record inserted...")
        }
        else
        {
            print("Failed")
        }

    }

    @IBAction func btnUpdate(_ sender: Any)
    {
        let query = "update emp set ename = '\(txtName.text!)',eadd = '\(txtAdd.text!)' where eid = '\(txtID.text!)'"
        print(query)
        let db = DMLOperations()
        let st = db.dml(query: query)
        if st == true
        {
            print("Record updated...")
        }
        else
        {
            print("Failed")
        }

    }
   
    @IBAction func btnDelete(_ sender: Any)
    {
        let query = "delete from emp where eid = '\(txtID.text)'"
        print(query)
        let db = DMLOperations()
        let st = db.dml(query: query)
        if st == true
        {
            print("Record deleted...")
        }
        else
        {
            print("Failed")
        }

    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as!custom
        
        return cell
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

