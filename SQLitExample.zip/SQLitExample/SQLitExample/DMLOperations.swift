//
//  DMLOperations.swift
//  SQLitExample
//
//  Created by TOPS on 10/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class DMLOperations: NSObject
{
    func dml(query:String) -> Bool
    {
        var status : Bool = false;
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path1 = path[0];
        let fullpath = path1.appending("/app.db");
        var op:OpaquePointer? = nil;
        if sqlite3_open(fullpath, &op) == SQLITE_OK
        {
            var stmt:OpaquePointer? = nil;
            if sqlite3_prepare_v2(op, query, -1, &stmt,nil) == SQLITE_OK
            {
                sqlite3_step(stmt);
                status = true
            }
            sqlite3_finalize(stmt);
            sqlite3_close(op);
        }
        return status
    }
    
    func getdata(strquery:String) -> [Any]
    {
        var arr:[Any] = [];
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path1 = path[0];
        let fullpath = path1.appending("/app.db");
        var op:OpaquePointer? = nil;
        if sqlite3_open(fullpath, &op) == SQLITE_OK
        {
            var stmt:OpaquePointer? = nil;
            if sqlite3_prepare_v2(op, strquery, -1, &stmt, nil) == SQLITE_OK
            {
                while sqlite3_step(stmt) == SQLITE_ROW
                {
                    var temp : [String] = []
                    let eid = String(cString:sqlite3_column_text(stmt, 0))
                    let ename = String(cString:sqlite3_column_text(stmt, 1))
                    let eadd = String(cString:sqlite3_column_text(stmt, 2))
                    temp.append(eid);
                    temp.append(ename);
                    temp.append(eadd);
                    arr.append(temp)
                }
            }
            sqlite3_finalize(stmt);
            sqlite3_close(op)
        }
        return arr
    }
}
