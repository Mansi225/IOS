//
//  ViewController.swift
//  MessagesMailingsAndShaing
//
//  Created by MAC2 on 16/11/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit
import Messages
import MessageUI

class ViewController: UIViewController,MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
    }

    @IBAction func msg(_ sender: Any)
    {
        var arr = ["111111111","2222222222"]
        var msg = MFMessageComposeViewController()
        msg.messageComposeDelegate = self
        msg.body = "hello"
        msg.title = "dfj"
        msg.recipients = arr
        if MFMessageComposeViewController.canSendText()
        {
            self.present(msg, animated: true, completion: nil)
        }
        else
        {
            print("Cannot send message")
        }
    }
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func mail(_ sender: Any)
    {
        let mail = MFMailComposeViewController()
        mail.mailComposeDelegate = self
        mail.setSubject("Feedback")
        mail.setToRecipients(["krimashah719@gmail.com"])
        mail.setMessageBody("<h1>What's your feedback?</h1>", isHTML: true)
        if MFMailComposeViewController.canSendMail()
        {
            self.present(mail, animated: true, completion: nil)
        }
        /*else
         {
         print("jhdjfghj")
         }*/
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func share(_ sender: Any)
    {
        var arr : [Any] = []
        arr.append("sdfkgf")
        let alt = UIActivityViewController(activityItems: arr, applicationActivities: nil)
        self.present(alt, animated: true, completion: nil)
    }
    
}

