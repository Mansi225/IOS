
import UIKit
import SkyFloatingLabelTextField
import SSBouncyButton

class ViewController: UIViewController,UINavigationControllerDelegate
{
    let con = controls()
    var name = SkyFloatingLabelTextFieldWithIcon()
    var mno = SkyFloatingLabelTextFieldWithIcon()
    var email = SkyFloatingLabelTextFieldWithIcon()
    var pass = SkyFloatingLabelTextFieldWithIcon()
    var cpass = SkyFloatingLabelTextFieldWithIcon()
    var reg = SSBouncyButton()
    var reset = SSBouncyButton()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        Addtxt()
        name.addTarget(self, action: #selector(self.validUname), for: .editingChanged)
        mno.addTarget(self, action: #selector(self.validMno), for: .editingChanged)
        email.addTarget(self, action: #selector(self.validEmail), for: .editingChanged)
        pass.addTarget(self, action: #selector(self.validPass), for: .editingChanged)
        cpass.addTarget(self, action: #selector(self.validCpass), for: .editingChanged)
    }
    
    func validUname(sender:SkyFloatingLabelTextFieldWithIcon)
    {
        
    }
    func validMno(sender:SkyFloatingLabelTextFieldWithIcon)
    {
        
    }
    func validEmail(sender:SkyFloatingLabelTextFieldWithIcon)
    {
        if isvalidEmail(email: email.text!)
        {
            email.rightViewMode = .never
            email.clipsToBounds = true
            email.layer.borderWidth = 2
            email.layer.borderColor = UIColor.green.cgColor
        }
        else
        {
            email.rightViewMode = .whileEditing
            let img = UIImageView(image: UIImage(named: "error@2x.png"))
            email.rightView = img
            email.clipsToBounds = true
            email.layer.borderWidth = 2
            email.layer.borderColor = UIColor.red.cgColor
        }
    }
    func validPass(sender:SkyFloatingLabelTextFieldWithIcon)
    {
        
    }
    func validCpass(sender:SkyFloatingLabelTextFieldWithIcon)
    {
        
    }
    
    func isvalidUname(uname:String) -> Bool
    {
            return true
    }
    func isvalidEmail(email:String) -> Bool
    {   let emailRegx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let etest = NSPredicate(format: "SELF MATCHES %@", emailRegx)
        let result = etest.evaluate(with: email)
        return result
    }
    func isvalidMno(mno:String) -> Bool
    {
        return true
    }
    func isvalidPass(pass:String) -> Bool
    {
        return true
    }
    func isvalidCpass(cpass:String) -> Bool
    {
        return true
    }
    
    func Addtxt()
    {
        name = con.textfield(frm: CGRect(x: 50, y: 150, width: 200, height: 45), placeholder: "Name", title: "User name", tintcolor: UIColor.gray, selectedtitlecolor: UIColor.cyan, linecolor: UIColor.cyan, icontype: .image, iconimage: UIImage(imageLiteralResourceName: "username.png"), iconcolor: UIColor.cyan)
        
        self.view.addSubview(name)
      
        mno = con.textfield(frm: CGRect(x: 50, y: 225, width: 200, height: 45), placeholder: "Mobile No.", title: "Enter your mobile No.", tintcolor: UIColor.gray, selectedtitlecolor: UIColor.cyan, linecolor: UIColor.cyan, icontype: .image, iconimage: UIImage(imageLiteralResourceName: "mobile.jpeg"), iconcolor: UIColor.cyan)
        self.view.addSubview(mno)
        
        email = con.textfield(frm: CGRect(x: 50, y: 300, width: 200, height: 45), placeholder: "Email-ID", title: "Enter your email id", tintcolor: UIColor.gray, selectedtitlecolor: UIColor.cyan, linecolor: UIColor.cyan, icontype: .image, iconimage: UIImage(imageLiteralResourceName: "email.png"), iconcolor: UIColor.cyan)
        self.view.addSubview(email)
        
        pass = con.textfield(frm: CGRect(x: 50, y: 375, width: 200, height: 45), placeholder: "Password", title: "Enter password", tintcolor: UIColor.gray, selectedtitlecolor: UIColor.cyan, linecolor: UIColor.cyan, icontype: .image, iconimage: UIImage(imageLiteralResourceName: "password.png"), iconcolor: UIColor.cyan)
        self.view.addSubview(pass)
        
        cpass = con.textfield(frm: CGRect(x: 50, y: 450, width: 200, height: 45), placeholder: "Confirm Password", title: "Same as password", tintcolor: UIColor.gray, selectedtitlecolor: UIColor.cyan, linecolor: UIColor.cyan, icontype: .image, iconimage: UIImage(imageLiteralResourceName: "cpass.png"), iconcolor: UIColor.cyan)
        self.view.addSubview(cpass)
        
       reg = con.button(frm: CGRect(x: 70, y: 550, width: 100, height: 30), title: "Register", tintcolor: UIColor.black, cornerradious: 5, bgcolor: UIColor.gray)
        reg.addTarget(self, action: #selector(self.register), for: .touchUpInside)
        self.view.addSubview(reg)
        
        reset = con.button(frm: CGRect(x: 200, y: 550, width: 100, height: 30), title: "Reset", tintcolor: UIColor.black, cornerradious: 5, bgcolor: UIColor.gray)
        reset.addTarget(self, action: #selector(self.resetbutton), for: .touchUpInside)
        self.view.addSubview(reset)

    }
    
    
    
    func resetbutton(sender:SSBouncyButton)
    {
        name.text = ""
        email.text = ""
        mno.text = ""
        pass.text = ""
        cpass.text = ""
    }
    func register(sender:SSBouncyButton)
    {
        if email.text != ""
        {
            if isvalidEmail(email: email.text!)
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "login")
                self.navigationController?.pushViewController(stb!, animated: true)
            }
            else
            {   print("not valid")
            }
        }
        else
        {   print("empty")
        }
        
    }
  
    
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }


}

