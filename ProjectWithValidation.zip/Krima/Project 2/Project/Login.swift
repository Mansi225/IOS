
import UIKit
import SkyFloatingLabelTextField
import SSBouncyButton


class Login: UIViewController,UINavigationControllerDelegate
{
    let con = controls()
    var uname = SkyFloatingLabelTextFieldWithIcon()
    var pass = SkyFloatingLabelTextFieldWithIcon()
    var btnlogin = SSBouncyButton()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

       cont()
    }

    
    
    func cont()
    {
        uname = con.textfield(frm: CGRect(x: 70, y: 150, width: 200, height: 45), placeholder: "Name", title: "User name", tintcolor: UIColor.gray, selectedtitlecolor: UIColor.cyan, linecolor: UIColor.cyan, icontype: .image, iconimage: UIImage(imageLiteralResourceName: "username.png"), iconcolor: UIColor.cyan)
        self.view.addSubview(uname)
        
        pass = con.textfield(frm: CGRect(x: 70, y: 225, width: 200, height: 45), placeholder: "Password", title: "Enter password", tintcolor: UIColor.gray, selectedtitlecolor: UIColor.cyan, linecolor: UIColor.cyan, icontype: .image, iconimage: UIImage(imageLiteralResourceName: "key.png"), iconcolor: UIColor.cyan)
        self.view.addSubview(pass)
        
        btnlogin = con.button(frm: CGRect(x: 125, y: 350, width: 100, height: 30), title: "Log In", tintcolor: UIColor.black, cornerradious: 5, bgcolor: UIColor.gray)
        btnlogin.addTarget(self, action: #selector(self.login), for: .touchUpInside)
        self.view.addSubview(btnlogin)

    }
    
    func login(sender:SSBouncyButton)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "extra")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
       
    }
}
