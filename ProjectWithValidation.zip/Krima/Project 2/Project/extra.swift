

import UIKit
import SkyFloatingLabelTextField

class extra: UIViewController {

    @IBOutlet weak var txtout: UITextField!
    
    @IBAction func txt(_ sender: Any)
    {
        print(txtout.text!)
        
    }
    
       override func viewDidLoad()
    {
        super.viewDidLoad()

        let txt = SkyFloatingLabelTextField(frame: CGRect(x: 20, y: 20, width: 200, height: 30))
        txt.placeholder = "name"
        txt.title = "your name"
        self.view.addSubview(txt)
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
       
    }
}
