

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{

    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var txtID: UITextField!
    @IBOutlet weak var txtname: UITextField!
    @IBOutlet weak var txtAdd: UITextField!
    @IBOutlet weak var btn: UIButton!
    
    var pos : Int = 0
    var finalarr : [Any] = []
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
       
        print(getpath())
        finalarr = getdata()
        let fmg = FileManager()
        if !fmg.fileExists(atPath: getpath())
        {
            var arr : [Any] = []
            let temp : [String:String] = [:]
            arr.append(temp)
            var dic : [String:Any] = [:]
            dic["Records"] = arr
            let finaldic = NSDictionary(dictionary: dic)
            finaldic.write(toFile: getpath(), atomically: true)
        }
    }

    func getpath() -> String
    {
        let arrpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arrpath[0] 
        let fullpath = path.appending("/profile.plist")
        return fullpath
    }
    
    func getdata() -> [Any]
    {
        print(getpath())
        let fmg = FileManager()
        if fmg.fileExists(atPath: getpath())
        {
            let dic = NSDictionary(contentsOfFile: getpath())
            print(dic ?? "ok")
            let arr = dic?.value(forKey: "Records") as! [Any]
            return arr
        }
        return []
    }
    
    func clear()
    {
        txtID.text = ""
        txtname.text = ""
        txtAdd.text = ""
    }
    
    @IBAction func btn_insert(_ sender: Any)
    {
        if btn.titleLabel?.text == "Update"
        {
            let fmg = FileManager()
            if fmg.fileExists(atPath: getpath())
            {
                let dic = NSDictionary(contentsOfFile: getpath())
                var arr = dic?["Records"] as! [Any]
                arr.remove(at: pos)
                let dic1 = ["eid":txtID.text!,"ename":txtname.text!,"eadd":txtAdd.text!]
                arr.append(dic1)
                dic?.setValue(arr, forKey: "Records")
                let finaldic = NSDictionary(dictionary: dic!)
                finaldic.write(toFile: getpath(), atomically: true)
                btn.setTitle("Insert", for: .normal)
                txtID.becomeFirstResponder()
                clear()
                finalarr = getdata()
                tbl.reloadData()
            }
        }
        
        else
        {
            print(getpath())
            let fmg = FileManager()
            if fmg.fileExists(atPath: getpath())
            {
                let dic = NSDictionary(contentsOfFile: getpath())
                var arr = dic?["Records"] as! [Any]
                let dic1 = ["eid":txtID.text!,"ename":txtname.text!,"eadd":txtAdd.text!]
                arr.append(dic1)
                dic?.setValue(arr, forKey: "Records")
                let finaldic = NSDictionary(dictionary: dic!)
                finaldic.write(toFile: getpath(), atomically: true)
                txtID.becomeFirstResponder()
                clear()
                finalarr = getdata()
                tbl.reloadData()
            }
        }
    }
    
    
    @IBAction func btn_disp(_ sender: Any)
    {
        let arrpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arrpath[0]
        let fullpath = path.appending("/profile.plist")
        print(fullpath)
        let fmg = FileManager()
        if fmg.fileExists(atPath: fullpath)
        {
            let dic = NSDictionary(contentsOfFile: fullpath)
            print(dic ?? "ok")
        }
    }

    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return finalarr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let dic = finalarr[indexPath.row] as! [String:String]
        cell.textLabel?.text = dic["ename"]
        cell.detailTextLabel?.text = dic["eadd"]
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        let dic = NSDictionary(contentsOfFile: getpath())
        var arr = dic?["Records"] as! [Any]
        arr.remove(at: indexPath.row)
        finalarr.remove(at: indexPath.row)
        dic?.setValue(arr, forKey: "Records")
        let finaldic = NSDictionary(dictionary: dic!)
        finaldic.write(toFile: getpath(), atomically: true)
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dic = finalarr[indexPath.row] as! [String:String]
        pos = indexPath.row
        txtID.text = dic["eid"]
        txtname.text = dic["ename"]
        txtAdd.text = dic["eadd"]
        btn.setTitle("Update", for: .normal)
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }


}

