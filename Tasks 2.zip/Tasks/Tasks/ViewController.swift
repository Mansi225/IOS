import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        createTextFiel()
        // Do any additional setup after loading the view, typically from a nib.
    }
    func createTextFiel()
    {
        let txt = UITextField(frame: CGRect(x: 10, y: 30, width: 200, height: 35))
        txt.placeholder = "Enter your name "
        txt.backgroundColor = UIColor.gray
        txt.tintColor = UIColor.black
        txt.addTarget(self, action: #selector(self.test), for:.touchUpInside)
        self.view.addSubview(txt)
    }
    @objc func test(sender:UITextField)
    {
        print("HELLo")
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

