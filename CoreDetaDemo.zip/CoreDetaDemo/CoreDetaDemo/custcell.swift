//
//  custcell.swift
//  CoreDetaDemo
//
//  Created by TOPS on 10/10/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class custcell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var lblid: UILabel!
    
    @IBOutlet weak var lblname: UILabel!
    
    @IBOutlet weak var lbladd: UILabel!
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
