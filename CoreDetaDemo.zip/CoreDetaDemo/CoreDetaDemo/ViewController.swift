//
//  ViewController.swift
//  CoreDetaDemo
//
//  Created by TOPS on 10/10/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{

    @IBOutlet weak var txtid: UITextField!
    
    @IBOutlet weak var txtname: UITextField!
    
    @IBOutlet weak var txtadd: UITextField!
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext;
    var arr:[Any] = []
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let entity = NSEntityDescription.entity(forEntityName: "Employee", in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = entity;
        do {
            var arr = try context.fetch(request)
            if arr.count > 0
            {
                let obj = arr[0] as! NSManagedObject;
                txtid.text = String(obj.value(forKey: "id") as! Int)
                txtname.text = obj.value(forKey: "name") as! String?
                txtadd.text = obj.value(forKey: "add") as! String?
            }
        } catch  {
            
        }

    }
    
    @IBAction func btnInsert(_ sender: Any)
    {
        let entity = NSEntityDescription.insertNewObject(forEntityName: "Employee", into: context)
        entity.setValue(Int(txtid.text!), forKey: "id")
        entity.setValue(txtname.text!, forKey: "name")
        entity.setValue(txtadd.text!, forKey: "add")
        do {
            try context.save();
            clear();
        } catch  {
            
        }
        
    }
    
    @IBAction func btnUpdate(_ sender: Any)
    {
        let entity = NSEntityDescription.entity(forEntityName: "Employee", in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = entity;
        let pred = NSPredicate(format: ("id = %@"), txtid.text!)
        request.predicate = pred;
        do {
            var arr = try context.fetch(request)
            if arr.count > 0 {
                let obj = arr[0] as! NSManagedObject;
                obj.setValue(Int(txtid.text!), forKey: "id")
                obj.setValue(txtname.text, forKey: "name")
                obj.setValue(txtadd.text, forKey: "add")
                do {
                    try context.save()
                    
                } catch  {
                
                }
            }
        } catch  {
            
            }
    }
    
    @IBAction func btnDelete(_ sender: Any)
    {
        let entity = NSEntityDescription.entity(forEntityName: "Employee", in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = entity;
        let pred = NSPredicate(format: ("id = %@"), txtid.text!)
        request.predicate = pred
        do {
            var arr = try context.fetch(request)
            if arr.count > 0 {
                let obj = arr[0] as! NSManagedObject;
                context.delete(obj)
                do {
                    try context.save()
                } catch  {
                    
                }
            }
        } catch  {
            
        }
    }
    
    @IBAction func btnSelect(_ sender: Any)
    {
        let entity = NSEntityDescription.entity(forEntityName: "Employee", in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = entity;
        let pred = NSPredicate(format: "id = %@", txtid.text!)
        request.predicate = pred;
        do {
            var arr = try context.fetch(request)
            if arr.count > 0
            {
                let obj = arr[0] as! NSManagedObject;
                txtid.text = String(obj.value(forKey: "id") as! Int)
                txtname.text = obj.value(forKey: "name") as! String?
                txtadd.text = obj.value(forKey: "add") as! String?
            }
        } catch  {
            
        }
    }
    
    func clear()
    {
        txtid.text = "";
        txtname.text = "";
        txtadd.text = "";
        txtname.becomeFirstResponder();
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let entity = NSEntityDescription.entity(forEntityName: "Employee", in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = entity;
        do {
            arr = try context.fetch(request)
           } catch  {
            
        }

        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! custcell
        let entity = NSEntityDescription.entity(forEntityName: "Employee", in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = entity;
        do {
            var arr = try context.fetch(request)
            if arr.count > 0
            {
                let obj = arr[indexPath.row] as! NSManagedObject;
                cell.lblid.text = String(obj.value(forKey: "id") as! Int)
                cell.lblname.text = obj.value(forKey: "name") as! String?
                cell.lbladd.text = obj.value(forKey: "add") as! String?
            }
        } catch  {
            
        }

        
        return cell
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }


}

